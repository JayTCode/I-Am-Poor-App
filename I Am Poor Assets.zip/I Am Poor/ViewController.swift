//
//  ViewController.swift
//  I Am Poor
//
//  Created by Binh Ta on 2022-03-16.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

